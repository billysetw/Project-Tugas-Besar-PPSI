<?php 

    $hostname = 'localhost';
    $username = 'root';
    $password = '';
    $dbname   = 'posi';

    $koneksi = mysqli_connect($hostname, $username, $password, $dbname);

    function query($query){
        global $koneksi;

        $ambil  = mysqli_query($koneksi, $query);
        $rows   = [];

        while ($row = mysqli_fetch_assoc($ambil)) {
            $rows[] = $row;
        }

        return $rows;
    }

    function login($data){
        global $koneksi;

        $User   = htmlspecialchars($data["User"]);
        $Pass   = htmlspecialchars($data["Pass"]);

        $query = "SELECT * FROM login WHERE User = '$Pass' AND User = '$Pass'";

        mysqli_query($koneksi, $query);

        return mysqli_affected_rows($koneksi);
    }

    function update($data){
        global $koneksi;

        $id_kegiatan        = $data['id_kegiatan'];
        $kegiatan_status    = htmlspecialchars($data['kegiatan_status']);
        $namaKegiatan       = htmlspecialchars($data['namaKegiatan']);
        $tanggalKegiatan    = htmlspecialchars($data['tanggalKegiatan']);
        $foto               = htmlspecialchars($data['foto']);

        $query = "UPDATE tb_kegiatan SET 
            kegiatan_status = '$kegiatan_status', 
            namaKegiatan = '$namaKegiatan', 
            tanggalKegiatan = '$tanggalKegiatan',  
            foto = ' ' WHERE id_kegiatan = $id_kegiatan";

        mysqli_query($koneksi, $query);

        return mysqli_affected_rows($koneksi);
    }
?>
<?php

	session_start();
	unset($_SESSION['User']);
	unset($_SESSION['login']);
	session_destroy();
	header("Location:../beranda.php");

?>
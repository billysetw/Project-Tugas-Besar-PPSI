<?php 
    

    include '../config.php';
    if(isset($_GET['idp'])){
        $foto = mysqli_query($koneksi, "SELECT foto FROM tb_kegiatan WHERE id_kegiatan = '".$_GET['idp']."' ");
        $p = mysqli_fetch_object($foto);

        unlink('../kegiatan/'.$p->foto);

        $delete = mysqli_query($koneksi, "DELETE FROM tb_kegiatan WHERE id_kegiatan = '".$_GET['idp']."' ");
        echo '<script>window.location="BerandaAdmin.php"</script>';
    }
?>
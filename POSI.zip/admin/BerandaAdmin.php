<?php 
    include '../config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>POSI Desa Jatisaba</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/logoPBG.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">
  <!-- <a href="berandaAdmin.php" class="logo"><img src="assets/img/logoPBG.png" alt="" class="img-fluid"></a> -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="berandaAdmin.php">POSI</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto" href="#hero">Beranda</a></li>
          <li><a class="nav-link scrollto" href="#kegiatan">Kegiatan</a></li>
          <li><a class="nav-link scrollto" href="../login/logout.php" style="border:2px solid white; color: red;" >LOGOUT</a></li>
          <li style="color:greenyellow; font-weight: bold;">ADMIN</li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <h3>Welcome to <strong>POSI</strong></h3>
      <h1>Portal Sistem Informasi</h1>
      <h2>Desa Jatisaba Purbalingga</h2>
      <h2 style="font-style: italic;">Anda adalah <b>Admin</b></h2>
    </div>
  </section><!-- End Hero -->

  <main id="main">
    <section id="kegiatan" class="portfolio">
      <div class="container">
        <div class="section-title">
          <h2>Tambah Kegiatan</h2>
        </div>
        <div class="section-title">
          <table border="0" align="center">
            <tr align="center">
              <form action="" method="POST" enctype="multipart/form-data">
                
                | <input type="text" name="namaKegiatan" placeholder="Nama Kegiatan" required> |
                <input type="date" name="tanggalKegiatan" placeholder="Tanggal Kegiatan" required> |
                <input type="file" name="foto" required> | 
                <select class="input-control" name="kegiatan_status">
                  <option value="">--Pilih--</option>
                  <option value="1">Aktif</option>
                  <option value="0">Tidak Aktif</option>
                </select> |
                <input type="submit" name="submit" value="Submit" class="btn"> |
              </form>
              <?php 

                  if(isset($_POST['submit'])){

                  // print_r($_FILES['foto']);
                  // menampung inputan dari form
                  $kegiatan_status  = $_POST['kegiatan_status'];
                  $namaKegiatan     = $_POST['namaKegiatan'];
                  $tanggalKegiatan  = $_POST['tanggalKegiatan'];
                  

                  // menampung data file yang diupload
                  $filename = $_FILES['foto']['name'];
                  $tmp_name = $_FILES['foto']['tmp_name'];

                  $type1 = explode('.', $filename);
                  $type2 = $type1[1];

                  $newname = 'foto'.time().'.'.$type2;

                  // menampung data format file yang diizinkan
                  $tipe_diizinkan = array('jpg', 'jpeg', 'png', 'gif');

                  // validasi format file
                  if(!in_array($type2, $tipe_diizinkan)){
                    // jika format file tidak ada di dalam tipe diizinkan
                    echo '<script>alert("Format file tidak diizinkan")</scrtip>';

                  }else{
                    // jika format file sesuai dengan yang ada di dalam array tipe diizinkan
                    // proses upload file sekaligus insert ke database
                    move_uploaded_file($tmp_name, '../kegiatan/'.$newname);

                    $insert = mysqli_query($koneksi, "INSERT INTO tb_kegiatan VALUES (' ','$kegiatan_status', '$namaKegiatan', '$tanggalKegiatan', '$newname')");

                    if($insert){
                      echo '<script>alert("Tambah data berhasil")</script>';
                      echo '<script>window.location="BerandaAdmin.php"</script>';
                    }else{
                      echo 'gagal '.mysqli_error($koneksi);
                    }
                  } 
                }
              ?>
            </tr>
            <tr><td colspan="6" bgcolor="#e43c5c" style="color:white;"></td></tr>
          </table>
        </div>
        <div class="section-title">
          <h2>Kegiatan</h2>
        </div>
       <table border="1" cellspacing="0" class="table">
          <thead>
            <tr>
              <th width="60px">No</th>
              <th>Foto</th>
              <th>Nama Kegiatan</th>
              <th>Tanggal Kegiatan</th>
              <th>Status</th>
              <th width="150px">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $no = 1;
              $kegiatan = mysqli_query($koneksi, "SELECT * FROM tb_kegiatan ORDER BY id_kegiatan DESC");
              if(mysqli_num_rows($kegiatan) > 0){
              while($row = mysqli_fetch_array($kegiatan)){
            ?>
            <tr>
              <td><?php echo $no++ ?></td> 
              <td><a href="kegiatan/<?php echo $row['foto'] ?>" target="_blank"> <img src="../kegiatan/<?php echo $row['foto'] ?>" width="50px"> </a></td>
              <td><?php echo $row['namaKegiatan'] ?></td>
              <td><?php echo $row['tanggalKegiatan'] ?></td>
              <td><?php echo ($row['kegiatan_status'] == 0)? 'Tidak Aktif':'Aktif'; ?></td>
              <td>
                <a href="hapusKegiatan.php?idp=<?php echo $row['id_kegiatan'] ?>" onclick="return confirm('Yakin ingin hapus ?')">Hapus</a>
              </td>
            </tr>
            <?php }}else{ ?>
              <tr>
                <td colspan="7">Tidak ada data</td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
    </section><!-- End Portfolio Section -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
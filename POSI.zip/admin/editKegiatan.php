<?php 
    include '../config.php';

    $id_kegiatan=$_GET['id_kegiatan'];

    $ambil= query("SELECT * FROM tb_kegiatan WHERE id_kegiatan = $id_kegiatan")[0];

    if (isset($_POST["submit"])) {
      if(update($_POST) > 0) {
        echo "
        <script>
        alert('Berhasil di edit');
        document.location.href = 'BerandaAdmin.php';
        </script>
        ";
      } else {
        echo "
        <script>
        alert('Gagal di edit');
        document.location.href = 'editKegiatan.php';
        </script>
        ";
      }
    }
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>POSI Desa Jatisaba</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/logoPBG.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">
  <!-- <a href="berandaAdmin.php" class="logo"><img src="assets/img/logoPBG.png" alt="" class="img-fluid"></a> -->
</head>

<body>
  <div class="section">
    <div class="container">
      <h1></h1>
      <h3>Edit Data Kegiatan</h3>
      <div class="box">
        <form action="" method="POST" enctype="multipart/form-data">
          <input type="hidden" name="id_kegiatan" value="<?php echo $ambil['id_kegiatan'] ?>">
          | <input type="text" name="namaKegiatan" class="input-control" placeholder="Nama Kegiatan" value="<?php echo $ambil['namaKegiatan' ]?>">
          | <input type="date" name="tanggalKegiatan" class="input-control" placeholder="Tanggal Kegiatan" value="<?php echo $ambil['tanggalKegiatan'] ?>">
          | <select class="input-control" name="kegiatan_status">
              <option value="">--Pilih--</option>
              <option value="1" <?php echo ($ambil['kegiatan_status'] == 1)? 'selected':''; ?>>Aktif</option>
              <option value="0" <?php echo ($ambil['kegiatan_status'] == 0)? 'selected':''; ?>>Tidak Aktif</option>
          | </select>
          | <input type="submit" name="submit" value="Submit" class="btn"> |
        </form>
      </div>
    </div>
  </div>
</body>
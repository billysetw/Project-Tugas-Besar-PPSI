<?php 
    include 'config.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>POSI Desa Jatisaba</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logoPBG.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Tempo - v4.7.0
  * Template URL: https://bootstrapmade.com/tempo-free-onepage-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="beranda.php">POSI</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logoPBG.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Beranda</a></li>
          <li><a class="nav-link scrollto" href="#services">Tentang</a></li>
          <li><a class="nav-link scrollto" href="#portfolio">Kegiatan</a></li>
          <li class="dropdown"><a href="#"><span>Lainnya</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#profil">Profil</a></li>
              <li><a href="#contact">Kontak</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="./login/login.php" style="border:2px solid white;">LOGIN</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <h3>Welcome to <strong>POSI</strong></h3>
      <h1>Portal Sistem Informasi</h1>
      <h2>Desa Jatisaba Purbalingga</h2>
      <a href="#services" class="btn-get-started scrollto">Get Started</a>
    </div>
  </section><!-- End Hero -->

  <main id="main">
    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="section-title">
          <h2>Tentang</h2>
          <h3>Pelayanan <span>Desa Jatisaba</span></h3>
        </div>

        <div class="row">
          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4 class="title"><a href="assets/dokumen/SYARAT-PEMBUATAN-KARTU-TANDA-PENDUDUK.pdf">KTP</a></h4>
              <p class="description">Untuk melakukan pembuatan KTP maka diperlukan data kelengkapan sebagai berikut.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4 class="title"><a href="assets/dokumen/SYARAT-PEMBUATAN-KARTU-KELUARGA.pdf">Kartu Keluarga</a></h4>
              <p class="description">Untuk melakukan pembuatan Kartu Keluarga maka diperlukan data kelengkapan sebagai berikut.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4 class="title"><a href="assets/dokumen/SYARAT-PEMBUATAN-KETERANGAN-AKTA-KELAHIRAN.pdf">Akta Kelahiran</a></h4>
              <p class="description">Untuk melakukan pembuatan Akta Kelahiran maka diperlukan data kelengkapan sebagai berikut.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4 class="title"><a href="assets/dokumen/SYARAT-PEMBUATAN-KETERANGAN-CATATAN-KEPOLISIAN.pdf">Surat Keterangan Catatan Kepolisian</a></h4>
              <p class="description">Untuk melakukan pembuatan Surat Keterangan Catatan Kepolisian maka diperlukan data kelengkapan sebagai berikut.</p>
            </div>
          </div>
          <div align="right"><a href="assets/dokumen/SYARAT-PEMBUATAN-KETERANGAN-USAHA.pdf">Lainnya...</a></div>
        </div>

      </div>
    </section><!-- End Services Section -->
    <hr>
    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container">

        <div class="section-title">
          <h2>Kegiatan</h2>
          <h3>Kegiatan pada <span>Desa Jatisaba</span></h3>
        </div>

        <div class="row portfolio-container">
          <div class="portfolio-item">
              <div class="section1">
              <div class="container1">
                <div class="box1">
                  <?php 
                    $kegiatan = mysqli_query($koneksi, "SELECT * FROM tb_kegiatan WHERE kegiatan_status = 1 ORDER BY id_kegiatan DESC LIMIT 8");
                    if(mysqli_num_rows($kegiatan) > 0){
                      while($p = mysqli_fetch_array($kegiatan)){
                  ?>  
                      <div class="col-4">
                        <img src="kegiatan/<?php echo $p['foto'] ?>">
                        <p class="namaKegiatan"><?php echo substr($p['namaKegiatan'], 0, 30) ?></p>
                        <p class="tanggalKegiatan"><?php echo $p['tanggalKegiatan'] ?></p>
                      </div>
                  <?php }}else{ ?>
                    <p>Kegiatan tidak ada</p>
                  <?php } ?>
                </div>
              </div>
            </div>
        </div>

      </div>
    </section><!-- End Portfolio Section -->
    <hr>
        <!-- ======= About Section ======= -->
    <section id="profil" class="about">
      <div class="container">

        <div class="section-title">
          <h2>Profil</h2>
          <h3>Visi</h3>
          <p>Menjadikan jatisaba yang lebih bangga dan berakhakul karimah.</p>
        </div>

        <div class="row content">
          <div class="">   
           <h2 align="center"><b>Misi</b></h2>
            <ul>
              <li style="margin-left: 280px">1. Menyelenggarakan pemerintahan yang profesional yang bersih.</li>
              <li style="margin-left: 280px">2. Mewujudkan masyarakat religius yang beriman dan bertaqwa kehadirat Allah SWT.</li>
              <li style="margin-left: 280px">3. Pembangunan infrastruktur yang merata.</li>
              <li style="margin-left: 280px">4. Membangun usaha ekonomi yang kreatif.</li>
              <li style="margin-left: 280px">5. Mewujudkan wilayah Jatisaba yang bersih, aman dan nyaman.</li>
            </ul>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->
    <hr>
    <!-- ======= Team Section ======= -->
    <section id="profil" class="profil">
      <div class="container">

        <div class="section-title">
          <h2>Profil</h2>
          <h3>Struktur Organisasi <span>Desa Jatisaba</span></h3>
        </div>

        <div class="row">
          <center>
          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/kepalaDesa.jpg" class="img-fluid" alt="">
              </div>
              <div class="member-info">
                <h5>Endah Herni Untari,S.T</h5>
                <span>Kepala Desa Jatisaba</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/sekertartisDesa.jpg" class="img-fluid" alt="">
              </div>
              <div class="member-info">
                <h5>Angkat Puji Purwoto,S.Kom</h5>
                <span>Sekertaris Desa Jatisaba</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/kaurtu.jpg" class="img-fluid" alt="">
              </div>
              <div class="member-info">
                <h5>Dwi Prasetyo</h5>
                <span>Kaur TU dan Umum</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/kasiKesejahteraan.jpg" class="img-fluid" alt="">
              </div>
              <div class="member-info">
                <h5>Mispianto</h5>
                <span>Kasi Kesejahteraan</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/kasiPelayanan.jpg" class="img-fluid" alt="">
              </div>
              <div class="member-info">
                <h5>Rukhyatno</h5>
                <span>Kasi Pelayanan</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/kadus3.jpg" class="img-fluid" alt="">
              </div>
              <div class="member-info">
                <h5>Azziz Zuhri</h5>
                <span>Kepala Dusun I</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/kadus2.jpg" class="img-fluid" alt="">
              </div>
              <div class="member-info">
                <h5>Kursono</h5>
                <span>Kepala Dusun II</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/kadus1.jpg" class="img-fluid" alt="">
              </div>
              <div class="member-info">
                <h5>Parsono</h5>
                <span>Kepala Dusun III</span>
              </div>
            </div>
          </div>
        </div>
      </center>
      </div>
    </section><!-- End Team Section -->
    <hr>
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2>Contact</h2>
          <h3>Contact <span>Us</span></h3>
          <table align="center">
            <tr align="left">
              <td>Contact Person</td>
              <td> : </td>
              <td> 081912302150 </td>
            </tr>
            <tr align="left">
              <td>Instagram</td>
              <td> : </td>
              <td> @desajatisaba </td>
            </tr> 
            <tr align="left">
              <td>Facebook</td>
              <td> : </td>
              <td> JATISABA PURBALINGGA </td>
            </tr>
          </table>                        
        </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">
    <div class="container d-md-flex py-4">
      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span>POSI</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
          Designed by <a href="https://bootstrapmade.com/">Institut Teknologi Telkom Purwokerto</a>
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://www.facebook.com/groups/162369050470597/?ref=share" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://instagram.com/desajatisaba?igshid=YmMyMTA2M2Y=" class="instagram"><i class="bx bxl-instagram"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>